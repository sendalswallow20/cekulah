<!-- Page Heading -->
 <div class="align-items-center justify-content-between col-xl-12 col-md-12">
    <h1 class="h3 mb-0 text-gray-800">Home</h1><br>
 </div>

   <div class="card-body">
        <h5>Selamat datang admin SDN Purwosari</h5>
    </div>